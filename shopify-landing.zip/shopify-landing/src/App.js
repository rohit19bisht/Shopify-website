import React from 'react';
import './App.css';
import './AppResponsive.css';

function App() {
  return (
    <React.Fragment>
      <div className="logo">
        <img src="/img/logo.svg" alt="Logo"/>
      </div>

      <section className="bannerSection">
        <div className="bannerInner">
          <div className="bannerContent">
            <h2>Fastest way to Design & Build you Ecommerce store</h2>
            <p>We help clients around the world to make their online stores,better, functional and user friendly.</p>
            <div className="bannerBtn">
              <a href="#!" className="mainBtn">Request a Call</a>
              <span>or &nbsp; Get your website audit for free</span>
            </div>
            <div className="rating">
              <img src="img/shopifyLogo.png" alt=""/>
              <div className="star">
                <i className="fa fa-star checked"></i>
                <i className="fa fa-star checked"></i>
                <i className="fa fa-star checked"></i>
                <i className="fa fa-star"></i>
                <i className="fa fa-star"></i>
              </div>
              <ul>
                <li>Most Trusted <b>E-commerce Expert</b></li>
                <li>Focused on <b>Driving sales</b></li>
              </ul>
            </div>
          </div>
          <div className="bannerImg">
            <img src="img/bannerImg.png" alt=""/>
          </div>
        </div>
      </section>

      <section className="bannerBottom">
        <div className="bannerLogo">
          <img src="img/shopifyLogo1.png" alt=""/>
        </div>
        <div className="bannerLogo">
          <img src="img/shopifyLogo2.png" alt=""/>
        </div>
        <div className="bannerLogo">
          <img src="img/shopifyLogo3.png" alt=""/>
        </div>
        <div className="bannerLogo">
          <img src="img/shopifyLogo4.png" alt=""/>
        </div>
      </section>

      <section className="projectGridSection">
        <div className="projectGridInner">
          <div className="projectGrid">
            <img src="img/projectGrid1.png" alt=""/>
          </div>
          <div className="projectGrid">
            <img src="img/projectGrid2.png" alt=""/>
          </div>
          <div className="projectGrid">
            <img src="img/projectGrid3.png" alt=""/>
          </div>
          <div className="projectGrid">
            <img src="img/projectGrid4.png" alt=""/>
          </div>
          <div className="projectGrid">
            <img src="img/projectGrid5.png" alt=""/>
          </div>
        </div>
        <div className="projectGridButton">
          <a href="#!" className="mainBtn">Get Started Now</a>
        </div>
      </section>

      <section className="trustedSection">
        <p><b>Trusted by</b> over 10,000 Shopify stores since 2015</p>
        <div className="trustedInner">
          <div className="trustedImg">
            <img src="img/trusted1.jpg" alt=""/>
          </div>
          <div className="trustedImg">
            <img src="img/trusted2.jpg" alt=""/>
          </div>
          <div className="trustedImg">
            <img src="img/trusted3.jpg" alt=""/>
          </div>
          <div className="trustedImg">
            <img src="img/trusted4.jpg" alt=""/>
          </div>
          <div className="trustedImg">
            <img src="img/trusted5.jpg" alt=""/>
          </div>
          <div className="trustedImg">
            <img src="img/trusted6.jpg" alt=""/>
          </div>
        </div>
      </section>

      <section className="weHelpSection">
        <h2 className="mobileHeading">We help E-commerce <span>Brands sell Faster</span></h2>
        <div className="weHelpContent">
          <h2>We help E-commerce <span>Brands sell Faster</span></h2>
          <p>We are a full service Web design and devlopment studio focussed on increasing sales for our clients while
            reducing their cost.</p>
          <ul>
            <li><b>600+</b><span>Websites <br/>Completed</span></li>
            <li><b>7</b><span>Years of <br/>Experience</span></li>
            <li><b>350+</b><span>Happy <br/>Customers</span></li>
          </ul>
        </div>
        <div className="weHelpImg">
          <img src="img/weHelp.jpg" alt=""/>
          <i className="fa fa-play"></i>
        </div>
      </section>

      <section className="whyChooseSection">
        <h2>Why Choose us</h2>
        <p>Here is what makes so special about flying saints</p>
        <div className="whyChooseInner">
          <div className="whyChooseImage">
            <img src="img/whyChoose.png" alt=""/>
          </div>
          <div className="whyChooseContent">
            <div className="whyChooseOption">
              <div className="chooseIcon"><img src="img/whyChooseOption1.svg" alt=""/></div>
              <p>Top Shopify Experts</p>
              <span>Dedicated shopify expert on every project. We give personal attention to each project.</span>
            </div>
            <div className="whyChooseOption">
              <div className="chooseIcon"><img src="img/whyChooseOption2.svg" alt=""/></div>
              <p>Flexible Pricing</p>
              <span>Whatever your requirement BIG or SMALL, We have tailor made flexible plans as your requirement.</span>
            </div>
            <div className="whyChooseOption">
              <div className="chooseIcon"><img src="img/whyChooseOption3.svg" alt=""/></div>
              <p>User experience experts</p>
              <span>E-commerce user experience experts who work towards optimising your store for better conversions.</span>
            </div>
            <div className="whyChooseOption">
              <div className="chooseIcon"><img src="img/whyChooseOption4.svg" alt=""/></div>
              <p>Mobile commerce specialists</p>
              <span>with over 80% audience is on mobile, so we focus on mobile first design.</span>
            </div>
          </div>
        </div>
      </section>

      <section className="checkSiteSection">
        <p>Check in your site in a minute</p>
        <h2>Audit your site for free</h2>
        <form>
          <div className="formGroup">
            <input type="text" name="" placeholder="Website URL"/>
          </div>
          <div className="formGroup">
            <input type="email" name="" placeholder="Work Email"/>
          </div>
          <div className="formGroup">
            <button className="mainBtn">Audit My Website</button>
          </div>
        </form>
      </section>

      <section className="portfolioSection">
        <div className="portfolio">
          <div className="portfolioLeft">
            <img src="img/n1.png" alt=""/>
          </div>
          <div className="portfolioRight">
            <img src="img/n2.png" alt=""/>
          </div>
        </div>
        <div className="portfolio2">
          <div className="portfolioLeft">
            <img src="img/t2.png" alt=""/>
          </div>
          <div className="portfolioRight">
            <img src="img/t1.png" alt=""/>
          </div>
        </div>
        <div className="portfolio3">
          <div className="portfolioLeft">
            <img src="img/o1.png" alt=""/>
          </div>
          <div className="portfolioRight">
            <img src="img/o2.png" alt=""/>
          </div>
        </div>
        <div className="portfolio4">
          <div className="portfolioLeft">
            <img src="img/m2.png" alt=""/>
          </div>
          <div className="portfolioRight">
            <img src="img/m1.png" alt=""/>
          </div>
        </div>
      </section>

      <section className="helpSection">
        <div className="helpImage">
          <img src="img/helpImage.png" alt=""/>
        </div>
        <div className="helpContent">
          <h2>We are ready to help you start your e-commerce store</h2>
          <p>Where our ecommerce expert will answer all your questions on how to get started</p>
          <a href="#!" className="mainBtn"><img src="img/calendly.svg" alt=""/>Book 15 min Discovery
            call</a>
        </div>
      </section>

      <section className="testimonialSection">
        <h2>What Customers Say about us</h2>
        <p>Our happy customers has something to say for our work</p>
        <div className="testimonialInner">
          <div className="testimonialGrid">
            <div className="testimonialCard">
              <div className="testimonialImg">
                <img src="img/testi1.jpg" alt=""/>
              </div>
              <div className="testimonialContent">
                <b>Ruchi Khera</b>
                <span>2 reviews</span>
                <ul>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li>A week ago</li>
                </ul>
                <p>The team communicates quickly and gets things done as promised !!</p>
                <div className="like"><i className="fa fa-thumbs-up"></i> Like</div>
              </div>
            </div>
            <div className="testimonialCard">
              <div className="testimonialImg">
                <img src="img/testi1.jpg" alt=""/>
              </div>
              <div className="testimonialContent">
                <b>Drishtana Singh</b>
                <span>2 reviews</span>
                <ul>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li>A week ago</li>
                </ul>
                <p>Most enthusiastic team. loved their ideas and suggestions. Thank you for ground me with brilliant
                  logo design</p>
                <div className="like"><i className="fa fa-thumbs-up"></i> Like</div>
              </div>
            </div>
          </div>
          <div className="testimonialGrid">
            <div className="testimonialCard">
              <div className="testimonialImg">
                <img src="img/testi1.jpg" alt=""/>
              </div>
              <div className="testimonialContent">
                <b>Junaid singh</b>
                <span>2 reviews</span>
                <ul>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li>A week ago</li>
                </ul>
                <p>Very nice problem solving approach and Very creative minds work behind the scenes to justify the
                  ideas. </p>
                <div className="like"><i className="fa fa-thumbs-up"></i> Like</div>
              </div>
            </div>
            <div className="testimonialCard">
              <div className="testimonialImg">
                <img src="img/testi1.jpg" alt=""/>
              </div>
              <div className="testimonialContent">
                <b>Vatsala CHaudhary</b>
                <span>2 reviews</span>
                <ul>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li>A week ago</li>
                </ul>
                <p>Team take a lot of effort in understanding your requirements & then delivering a website of high
                  quality. I strongly recommend if you are looking to get an awesome landing page or website designed
                  with finesse.</p>
                <div className="like"><i className="fa fa-thumbs-up"></i> Like</div>
              </div>
            </div>
          </div>
          <div className="testimonialGrid">
            <div className="testimonialCard">
              <div className="testimonialImg">
                <img src="img/testi1.jpg" alt=""/>
              </div>
              <div className="testimonialContent">
                <b>Saumya Jagat</b>
                <span>2 reviews</span>
                <ul>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li>A week ago</li>
                </ul>
                <p>They designed our current homepage. Which is highly effective. Kudos to the team.</p>
                <div className="like"><i className="fa fa-thumbs-up"></i> Like</div>
              </div>
            </div>
            <div className="testimonialCard">
              <div className="testimonialImg">
                <img src="img/testi1.jpg" alt=""/>
              </div>
              <div className="testimonialContent">
                <b>Rajat Soni</b>
                <span>2 reviews</span>
                <ul>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star checked"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li><i className="fa fa-star"></i></li>
                  <li>A week ago</li>
                </ul>
                <p>Well Process oriented company, very happy with the design sprint Practice we had with the flying
                  saints team.</p>
                <div className="like"><i className="fa fa-thumbs-up"></i> Like</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="whatWeSection">
        <h2>What we can do for you</h2>
        <p>Here are a few of the most popular task requests we get <span>from Shopify store owners</span></p>
        <div className="whatWeInner">
          <div className="whatWeLeft">
            <div className="whatWeGrid">
              <div className="whatWeIcon">
                <img src="img/tick.svg" alt=""/>
              </div>
              <div className="whatWeContent">
                <h3>store build or redesign</h3>
                <p>Here are a few of the most popular task requests we get from Shopify store owners</p>
              </div>
            </div>
            <div className="whatWeGrid">
              <div className="whatWeIcon">
                <img src="img/tick.svg" alt=""/>
              </div>
              <div className="whatWeContent">
                <h3>App installation</h3>
                <p>Here are a few of the most popular task requests we get from Shopify store owners</p>
              </div>
            </div>
            <div className="whatWeGrid">
              <div className="whatWeIcon">
                <img src="img/tick.svg" alt=""/>
              </div>
              <div className="whatWeContent">
                <h3>Custom theme design</h3>
                <p>Here are a few of the most popular task requests we get from Shopify store owners</p>
              </div>
            </div>
          </div>
          <div className="whatWeLeft">
            <div className="whatWeGrid">
              <div className="whatWeIcon">
                <img src="img/tick.svg" alt=""/>
              </div>
              <div className="whatWeContent">
                <h3>Custom commerce experience</h3>
                <p>Here are a few of the most popular task requests we get from Shopify store owners</p>
              </div>
            </div>
            <div className="whatWeGrid">
              <div className="whatWeIcon">
                <img src="img/tick.svg" alt=""/>
              </div>
              <div className="whatWeContent">
                <h3>Site performance & speed guidance</h3>
                <p>Here are a few of the most popular task requests we get from Shopify store owners</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="contactSection">
        <div className="contactForm">
          <h2>Contact Us</h2>
          <form>
            <div className="formGroup">
              <input type="text" name="" placeholder="Work Email"/>
            </div>
            <div className="formGroup">
              <select>
                <option>What this about?</option>
              </select>
            </div>
            <div className="formGroup formGroup2">
              <textarea rows="7" placeholder="Message"></textarea>
            </div>
            <div className="formGroup formGroup2">
              <button className="mainBtn">Submit</button>
            </div>
          </form>
        </div>
        <div className="contactImg">
          <img src="img/contactImage.png" alt=""/>
        </div>
      </section>
    </React.Fragment>
  );
}

export default App;
